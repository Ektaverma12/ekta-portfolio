EKTA VERMA PORTFOLIO

Files: index.html, style.css, script.js, resume.pdf

Deploy on GitHub + Vercel:
1. Upload these files to your GitHub repository.
2. Keep resume.pdf in the repository root.
3. Vercel will redeploy automatically after the GitHub push.

To add a future project, copy any <article class="project">...</article> block in index.html, change its number/title/description/technology line, and save.

Phone: +91 7202805964 (clickable)
Email: ektaverma1219@gmail.com
GitHub: https://github.com/Ektaverma12
LinkedIn: https://www.linkedin.com/in/ekta-verma-21043934a/
