EKTA VERMA PORTFOLIO — UPDATED

Changes:
- Removed Data Analytics as the main identity/title.
- Broadened profile to technology/internship opportunities.
- Added C, Python, Java, JavaScript, MongoDB, NoSQL, Android/Kotlin/XML, APIs, OOP and Software Testing.
- Added clickable phone links. Replace +91XXXXXXXXXX with your real number.
- Future projects can be added by copying an existing project card in index.html.
- Resume button uses resume.pdf; upload your actual PDF with that exact filename.

After replacing these files in GitHub, Vercel will automatically redeploy.
